SparkFun <PRODUCT NAME>
========================================

![SparkFun Part Name](URL for picture of part)

[*SparkFun Part Name (SKU)*](URL for product on Sparkfun.com)

<Basic description of the part.>

Repository Contents
-------------------

* **/Documentation** - Data sheets, additional product information
* **/Enclosure** - Enclosure files 
* **/Firmware** - Example code 
* **/Hardware** - Eagle design files (.brd, .sch)
* **/Libraries** - Libraries for use with the <PRODUCT NAME>
* **/Production** - Production panel files (.brd)
* **/Software** - Related software for the <PRODUCT NAME>

Documentation
--------------
* **[Library](GitHub library URL)** - <LANGUAGE> library for the <PRODUCT NAME>.
* **[Hookup Guide](Learn.SparkFun URL)** - Basic hookup guide for the <PRODUCT NAME>.
* **[SparkFun Fritzing repo](https://github.com/sparkfun/Fritzing_Parts)** - Fritzing diagrams for SparkFun products.
* **[SparkFun 3D Model repo](https://github.com/sparkfun/3D_Models)** - 3D models of SparkFun products. 
* **[SparkFun Graphical Datasheets](https://github.com/sparkfun/Graphical_Datasheets)** -Graphical Datasheets for various SparkFun products.

Product Versions
----------------
* [Part SKU](part URL)- Basic part and short description here
* [Retail part SKU] (retail URL)- Retail packaging of standard description here
* [Any other parts this repo covers](any other URLs) - Description of said parts

Version History
---------------
* [vExxFxxZxxHxxLxxSxx](URL for tag specific to this version) - Description 
* [vEyyFyyZyyHyyLyySyy](URL for tag specific to this version) - Description

License Information
-------------------

This product is _**open source**_! 

Please review the LICENSE.md file for license information. 

If you have any questions or concerns on licensing, please contact techsupport@sparkfun.com.

Distributed as-is; no warranty is given.

- Your friends at SparkFun.

_<COLLABORATION CREDIT>_
